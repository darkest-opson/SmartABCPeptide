import streamlit as st
import py3Dmol
import requests

def render_mol(pdb):
    """Render the protein structure using py3Dmol."""
    pdbview = py3Dmol.view()
    pdbview.addModel(pdb, 'pdb')
    pdbview.setStyle({'cartoon': {'color': 'spectrum'}})
    pdbview.setBackgroundColor('white')
    pdbview.zoomTo()
    pdbview.zoom(1, 100)
    return pdbview

def update(sequence):
    """Fetch the protein structure using the ESMFold API and render it."""
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    response = requests.post(
        'https://api.esmatlas.com/foldSequence/v1/pdb/',
        headers=headers,
        data=sequence,
        verify=False  # Disable SSL verification for testing purposes
    )
    pdb_string = response.content.decode('utf-8')
    return pdb_string

