from admet_ai import ADMETModel
import pandas as pd
from rdkit import Chem

def peptide_admet(pep_seq):
  # Convert sequence to SMILES string
  smiles_string = Chem.MolToSmiles(Chem.MolFromSequence(pep_seq))
  model = ADMETModel()
  preds = model.predict(smiles=smiles_string)
  df = pd.DataFrame(preds,index=[0])
  df.insert(0,"Sequence",pep_seq)
  return df

# need to download pip install setuptools