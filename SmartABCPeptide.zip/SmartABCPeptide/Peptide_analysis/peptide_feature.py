from Bio.SeqUtils.ProtParam import ProteinAnalysis
from collections import Counter
from Bio.Seq import Seq
import math
import pandas as pd
# Define the function to calculate the aliphatic index
def aliphatic_index(seq):
    A = seq.count('A')
    V = seq.count('V')
    I = seq.count('I')
    L = seq.count('L')
    N = len(seq)

    return (A + 2.9 * V + 3.9 * (I + L)) / N

# Define the function to calculate the hydrophobic moment
def hydrophobic_moment(seq, angle=100):
  # Define the hydrophobicity scale (e.g., Kyte-Doolittle scale)
    hydrophobicity = {
    'A': 1.8, 'C': 2.5, 'D': -3.5, 'E': -3.5, 'F': 2.8,
    'G': -0.4, 'H': -3.2, 'I': 4.5, 'K': -3.9, 'L': 3.8,
    'M': 1.9, 'N': -3.5, 'P': -1.6, 'Q': -3.5, 'R': -4.5,
    'S': -0.8, 'T': -0.7, 'V': 4.2, 'W': -0.9, 'Y': -1.3
      }

    angle_rad = math.radians(angle)
    hydrophobic_moment_value = 0
    for i, amino_acid in enumerate(seq):
        if amino_acid in hydrophobicity:
            hydrophobic_moment_value += hydrophobicity[amino_acid] * math.cos(i * angle_rad)
    return hydrophobic_moment_value / len(seq)


def peptides_info(pep_seq):
  X = ProteinAnalysis(pep_seq)
  sec = [round(x,2) for x in X.secondary_structure_fraction()]
  aa_per = X.get_amino_acids_percent()
  for key,value in aa_per.items():
    aa_per[key] = round(value*100,4)


  peptide_dic = {
    "Sequence" : pep_seq,
      "amino_acids_percentage" : X.get_amino_acids_percent(),
      "molecular_weight" : round(X.molecular_weight(),4),
      "aromaticity" : round(X.aromaticity(),4),
      "instability_index" : round(X.instability_index(),4),
      "isoelectric_point" : round(X.isoelectric_point(),4),
      "secondary_structure_fraction" : sec,
      "molar_extinction_coefficient" : X.molar_extinction_coefficient(),
      "gravy" : round(X.gravy(),4),
      "flexibility" : X.flexibility(),
      "charge_at_pH" : round(X.charge_at_pH(7),4),
      "amino_acids_content" : X.amino_acids_content,
      "amino_acids_percent" : aa_per,
      "length" : len(pep_seq)
  }

  count = Counter(pep_seq)

    # Find the most common element
  most_common_element, most_common_frequency = count.most_common(1)[0]

    # Find the least common element
  least_common_element, least_common_frequency = min(count.items(), key=lambda x: x[1])

  peptide_dic["most_common_amino_acid"] = most_common_element
  peptide_dic["most_common_amino_acid_frequency"] = most_common_frequency
  peptide_dic["least_common_amino_acid"] = least_common_element
  peptide_dic["least_common_amino_acid_frequency"] = least_common_frequency

  peptide = Seq(pep_seq)
  # Define sets of hydrophilic and hydrophobic amino acids
  hydrophilic_amino_acids = {
    'S', 'T', 'N', 'Q', 'Y',  # Polar (Uncharged)
    'K', 'R', 'H',            # Basic
    'D', 'E'                  # Acidic
    }

  hydrophobic_amino_acids = {
    'A', 'I', 'L', 'M', 'F', 'W', 'V', 'P', 'G', 'C'
    }
  hydrophilic = []
  hydrophobic = []

  for amino_acid in peptide:
      if amino_acid in hydrophilic_amino_acids:
          hydrophilic.append(amino_acid)
      elif amino_acid in hydrophobic_amino_acids:
          hydrophobic.append(amino_acid)
  try:
    ratio = float(len(hydrophobic))/float(len(hydrophilic))
  except:
    ratio = "infinite"
  peptide_dic["hydrophilic_hydrophobic_ratio"] = ratio

  all_amino_acids = set('ACDEFGHIKLMNPQRSTVWY')
    # Create a set of amino acids in the peptide
  peptide_amino_acids = set(pep_seq)

    # Find the missing amino acids
  missing_amino_acids = all_amino_acids - peptide_amino_acids
  if missing_amino_acids:
    peptide_dic["missing_amino_acids"] = ",".join(list(missing_amino_acids))
  else:
    peptide_dic["missing_amino_acids"] = "None"
  # Calculate the aliphatic index
  aliphatic_idx = aliphatic_index(pep_seq)

# Calculate the hydrophobic moment
  hydrophobic_moment_value = hydrophobic_moment(pep_seq)
  peptide_dic["aliphatic_index"] = round(aliphatic_idx,4)
  peptide_dic["hydrophobic_moment"] = round(hydrophobic_moment_value,4)

  return pd.json_normalize(peptide_dic)


# print((peptides_info("ALKMN")))