import pandas as pd
from rdkit.Chem import Descriptors, MolFromSmiles
from rdkit import Chem

def peptide_mol_descriptors(pep_seq):
  sequence = pep_seq
  # Convert sequence to SMILES string
  smiles_string = Chem.MolToSmiles(Chem.MolFromSequence(sequence))

  # Create an RDKit molecule object
  mol = MolFromSmiles(smiles_string)

  # Calculate molecular descriptors
  descrs = Descriptors._descList

  # Initialize an empty dictionary to store descriptor values
  desc_values = {}

  # Calculate each descriptor value for the molecule
  for desc_name, descriptor in descrs:
      desc_value = descriptor(mol)
      desc_values[desc_name] = desc_value

  # Convert the dictionary to a DataFrame
  df = pd.DataFrame(desc_values, index=[0])
  # df["Sequnece"] = pep_seq
  df.insert(0,"Sequnece",pep_seq)
  return df
  
# print(peptide_mol_descriptors("ALKKM"))