# app.py
import streamlit as st
import pandas as pd
from abcp_classification_function import classify_peptide

st.set_page_config(
    page_title="SmartABCPeptide",
    layout="centered",
    page_icon="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9WjEbOoAAAAASUVORK5CYII="
)
st.title("SmartABCPeptide")

st.markdown(
    """
    <div style='background-color: #f0f2f6; border-radius: 10px; padding: 16px; margin-bottom: 16px;color: #333;'>
    <h4 style='margin-bottom: 10px;'>About this tool</h4>
    <p>
    <b>ABCP Classifier</b> is a machine learning-based web application designed for the classification of anticancer peptides (ACPs) and non-ACPs from protein/peptide sequences. It supports both single and batch prediction in FASTA or plain sequence format.<br><br>
    <b>Usage:</b> Paste your peptide sequences (FASTA or one-per-line) or upload a FASTA file, then click <i>Classify</i> to view and download results.
    </p>
    </div>
    """,
    unsafe_allow_html=True,
)

input_method = st.radio("Input method:",["Manual sequence(s)", "Upload FASTA file"])

def parse_fasta(raw_text):
    """Parse (multi-)FASTA or line-by-line input into [(id, sequence), ...]"""
    records = []
    seq_id = None
    seq_lines = []
    lines = [line.strip() for line in raw_text.strip().splitlines() if line.strip()]
    for line in lines:
        if line.startswith(">"):
            if seq_id is not None:
                records.append((seq_id, ''.join(seq_lines)))
            seq_id = line[1:].strip()
            seq_lines = []
        else:
            seq_lines.append(line)
    if seq_id is not None:
        records.append((seq_id, ''.join(seq_lines)))
    # If no FASTA header is found, treat each non-empty line as a separate sequence
    if not records and lines:
        for idx, seq in enumerate(lines):
            records.append((f"Input_{idx+1}", seq))
    return records

sequence_input = None

if input_method == "Manual sequence(s)":
    sequence_input = st.text_area(
        "Paste your peptide sequence(s) (FASTA format or one-per-line raw)", height=150)
else:
    fasta_file = st.file_uploader("Upload a FASTA file", type=["fa", "fasta"])
    if fasta_file:
        sequence_input = fasta_file.getvalue().decode("utf-8")

if st.button("Classify"):
    if not sequence_input or not sequence_input.strip():
        st.warning("Please provide at least one peptide sequence.")
    else:
        try:
            records = parse_fasta(sequence_input)
            results = []
            for seq_id, seq in records:
                pred_class, pred_prob = classify_peptide(f">{seq_id}\n{seq}")
                results.append({
                    "Identifier": seq_id,
                    "Sequence": seq,
                    "Predicted Class": pred_class,
                    "Predicted Probability": f"{pred_prob:.4f}"
                })
            results_df = pd.DataFrame(results)
            st.success("Classification results:")
            st.dataframe(results_df)
            # CSV Download
            csv = results_df.to_csv(index=False)
            st.download_button(
                label="Download results as CSV",
                data=csv,
                file_name="abcp_classification_results.csv",
                mime="text/csv"
            )
        except Exception as e:
            st.error(f"Error during classification:\n{e}")


# Footer
st.markdown(
    """
    <hr>
    <div style='text-align: center; font-size: 15px; color: #666; margin-top: 30px;'>
    Developed by <b>System Biology Laboratory</b> <br><b>Indian Institute of Information Technology Allahabad</b>, Prayagraj, Uttar Pradesh, India
    </div>
    """,
    unsafe_allow_html=True,
)   